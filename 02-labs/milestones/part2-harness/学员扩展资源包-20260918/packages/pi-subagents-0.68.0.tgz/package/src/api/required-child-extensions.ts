export {
	registerRequiredChildExtensions,
	type RegisterRequiredChildExtensionsInput,
	type RequiredChildExtension,
	type RequiredChildExtensionRegistration,
} from "../shared/required-child-extensions.ts";
